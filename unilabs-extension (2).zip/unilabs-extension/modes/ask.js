(() => {
    const question = prompt("Твой вопрос для ChatGPT 4o?")

    const body = {
        "model": "gpt-4o-mini",
        "messages": [
            {
              "role": "user", 
               "content": `${question}`
            }
          ],
        "temperature": 0.7
      };

    fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer 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'
        },
        body: JSON.stringify(body)
      })
        .then(response => response.json()
        .then(data => alert(data.choices[0].message.content))
        .catch(error => {
            alert('Error :)')
            console.log(error)
        }));

})();
  