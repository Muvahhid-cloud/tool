(() => {

  const load = () => {
    document.body.style.cursor = "crosshair";

    registerListeners();
  }

  const unload = () => {
    document.body.style.cursor = "";

    unregisterListeners();
  }

  /* Listeners */

  const registerListeners = () => {
    document.addEventListener("mouseover", mouseOver);
    document.addEventListener("mouseout", mouseOut);

    document.addEventListener("click", mouseClick);
  }

  const unregisterListeners = () => {
    document.removeEventListener("mouseover", mouseOver);
    document.removeEventListener("mouseout", mouseOut);

    document.removeEventListener("click", mouseClick);
  }

  /* Events */

  const mouseOver = (event) => {
    event.target.style.border = "1px dashed gray";
    event.target.style.cursor = "pointer";
  }

  const mouseOut = (event) => {
    event.target.style.border = "";
  }

  const mouseClick = (event) => {
    handleClick(event)
  }

  /* Notification */

  const showNotification = (text) => {
    document.body.style.position = "relative";

    // notification
    const notification = document.createElement("div");

    notification.innerText = text;

    notification.style.position = "fixed";
    notification.style.bottom = "12px";
    notification.style.right = "12px";
    notification.style.backgroundColor = "rgb(0, 0, 0, 0.05)";
    notification.style.padding = "12px";
    notification.style.color = "rgb(0, 0, 0, 0.5)";
    notification.style.borderRadius = "12px";
    notification.style.maxWidth = "250px";
    notification.style.maxHeight = "150px";
    notification.style.overflowY = "scroll";

    notification.onclick = () => {
      document.body.removeChild(notification);
    };

    document.body.appendChild(notification);

    // progress
    const progress = document.createElement("div");
    progress.style.position = "absolute";
    progress.style.bottom = "0";
    progress.style.left = "0";
    progress.style.width = "0%";
    progress.style.height = "5px";
    progress.style.backgroundColor = "black";
    progress.style.opacity = '0.1';
    progress.style.transition = "width 3s linear";

    notification.appendChild(progress);

    setTimeout(() => {
      progress.style.width = "100%";
    }, 10);

    setTimeout(() => {
      document.body.removeChild(notification);
      document.body.removeChild(progress);

      return () => {
        document.body.removeChild(notification);
        document.body.removeChild(progress);
      }

    }, 3000);

  }

  /* other */

  const handleClick = (event) => {
    
    const questionType = getType(event);
    unload();

    if (questionType == 'ABC') {
      abcType(event);
    } else {
      chooseType(event)
    }
    
  };

  const getType = (event) => {
    const selectedElement = event.target;
    event.target.style.border = "";

    if (selectedElement) {
      question = selectedElement.innerText.trim();
      window.question = question;

      const parentFormulation = selectedElement.closest('.formulation');
      const answer = parentFormulation.querySelector('.answer')

      if (answer.tagName == 'DIV') {
        return "ABC";
      } else if (answer.tagName == 'TABLE') {
        return "CHOOSE";
      }
    }

    return "ABC";
  }

  const abcType = (event) => {
    
    const parseQuestion = (event) => {
      const selectedElement = event.target;
      event.target.style.border = "";

      let question = "";
      let answers = [];
  
      if (selectedElement) {
        question = selectedElement.innerText.trim();
  
        const parentFormulation = selectedElement.closest('.formulation');
  
        if (parentFormulation) {
          answers = Array.from(parentFormulation.querySelectorAll('.answer'))
            .map(answer => answer.innerText.trim());
        }
      }

      return {
        "question": question,
        "answers": answers
      }
    }
    
    const data = parseQuestion(event);

    const body = {
      "model": "gpt-4o-mini",
      "messages": [
        {
          "role": "user",
          "content": "Я тебе скину вопрос и массив из ответов. Выбери правильный ответ из массива и ответь мне. Мне нужен только ответ. Для примера: Question: 2+5?, Answers: [1, 3, 5, 7]. Твой ответ: 7"
        },
        {
          "role": "user",
          "content": `Question: ${data.question}, Answers: [${data.answers.join(', ')}]`
        }
      ],
      "temperature": 0.7
    };

    fetchGPT(body)
  }

  const chooseType = (event) => {

    const parseQuestion = (event) => {
      const selectedElement = event.target;
      event.target.style.border = "";

      let questions = [];
  
      if (selectedElement) {

        const formulation = selectedElement.closest('.formulation');

        Array.from(formulation.querySelectorAll('.r0, .r1'))
          .map(r => {
            
            let question = r.querySelectorAll('.text')[0].innerText;
            let answers = [];

            Array.from(formulation.querySelector('.select').children)
              .map(answer => answers.push(answer.innerText.trim()))

              questions.push({
                "question": question,
                "answers": answers
              })
          })

      }

      return questions;
    }

    const data = parseQuestion(event);

    let questions = '';

    data.map((d) => questions += `Question: ${d.question}, Answers: [${d.answers.join(', ')}]`)

    const body = {
      "model": "gpt-4o-mini",
      "messages": [
        {
          "role": "user",
          "content": "Я тебе скину вопрос и массив из ответов. Выбери правильный ответ из массива и ответь мне. Мне нужен только ответ. Для примера: Question: 2+5?, Answers: [1, 3, 5, 7]. Твой ответ: 7. Если вопросов много, то отвечай так: 1. ответ\n 2. ответ\n 3. ответ"
        },
        {
          "role": "user",
          "content": questions
        }
      ],
      "temperature": 0.7
    };

    fetchGPT(body)

  }

  const fetchGPT = (body) => {
    fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer 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'
      },
      body: JSON.stringify(body)
    })
      .then(response => response.json()
        .then(data => {
          const response = data.choices[0].message.content;
          showNotification(response)
        })
        .catch(error => {
          alert('Error :)')
          console.log(error)
        }));
  }

  load();

})();
