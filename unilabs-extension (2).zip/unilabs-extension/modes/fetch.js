(() => {
  
    if (!window.answers) {
        window.answers = [];
    }

    if (!window.question) {
        window.question = "";
    }

    const body = {
        "model": "gpt-4o-mini",
        "messages": [
            {
              "role": "user", 
               "content": "Я тебе скину вопрос и массив из ответов. Выбери правильный ответ из массива и ответь мне. Мне нужен только ответ. Для примера: Question: 2+5?, Answers: [1, 3, 5, 7]. Твой ответ: 7"
            },
            {
              "role": "user", 
               "content": `Question: ${window.question}, Answers: [${window.answers.join(', ')}]`
            }
          ],
        "temperature": 0.7
      };

    fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer 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'
        },
        body: JSON.stringify(body)
      })
        .then(response => response.json()
        .then(data => alert(data.choices[0].message.content))
        .catch(error => {
            alert('Error :)')
            console.log(error)
        }));
      
  })();
  